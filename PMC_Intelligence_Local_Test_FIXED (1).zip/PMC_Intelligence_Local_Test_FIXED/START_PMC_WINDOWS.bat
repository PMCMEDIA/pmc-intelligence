@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% neq 0 (echo Python 3 is required. Install Python 3 from python.org and try again.& pause & exit /b 1)
if not exist ".venv" py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt
start "" http://127.0.0.1:5000
python app.py
pause
