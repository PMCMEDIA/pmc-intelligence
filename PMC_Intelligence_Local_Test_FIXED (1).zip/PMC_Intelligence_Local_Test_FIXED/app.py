from flask import Flask, request, jsonify, send_file, render_template
from pathlib import Path
import json, uuid, re
from research_engine import research_url, discovery_questions
from strategy_engine import build_strategy
from deck_engine import generate

ROOT=Path(__file__).parent
DATA=ROOT/'data'; OUT=ROOT/'generated'
DATA.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
app=Flask(__name__, template_folder='templates')

@app.get('/')
def home(): return render_template('index.html')

@app.post('/api/projects')
def create():
    p=request.json or {}
    research=research_url(p.get('url',''))
    d={'id':str(uuid.uuid4())[:8], **p, 'research':research,
       'questions':discovery_questions(research,p.get('industry','Other'))}
    d['strategy']=build_strategy(p,research)
    (DATA/f"{d['id']}.json").write_text(json.dumps(d,indent=2), encoding='utf-8')
    return jsonify(d)

@app.get('/api/projects/<pid>/deck')
def deck(pid):
    f=DATA/f'{pid}.json'
    if not f.exists(): return jsonify({'error':'Project not found'}),404
    d=json.loads(f.read_text(encoding='utf-8'))
    safe=re.sub(r'[^A-Za-z0-9_-]+','_',d['client']).strip('_') or 'Client'
    out=OUT/f'{safe}_PMC_Strategy_Draft.pptx'
    generate(d,out)
    return send_file(out,as_attachment=True,download_name=out.name)

@app.get('/health')
def health(): return {'ok':True,'version':'4-local-fixed','website_research':True,'pptx_export':True}

if __name__=='__main__': app.run(host='127.0.0.1',port=5000,debug=False)
