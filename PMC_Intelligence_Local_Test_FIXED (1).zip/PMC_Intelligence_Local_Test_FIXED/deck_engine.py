from pptx import Presentation
from pathlib import Path
import re
ROOT=Path(__file__).parent
MASTER=ROOT/"master"/"PMC_Master_Strategy.pptx"
SLIDES=[1,5,11,12,13,14,15,16,17,18,22,23,25,26,29,32,33,44,45,46,86]

def _delete(prs,i):
    sid=prs.slides._sldIdLst[i]
    prs.part.drop_rel(sid.rId)
    prs.slides._sldIdLst.remove(sid)

def generate(project, output):
    prs=Presentation(str(MASTER))
    keep={n-1 for n in SLIDES}
    for i in range(len(prs.slides)-1,-1,-1):
        if i not in keep: _delete(prs,i)
    client=project["client"]
    reps={"DeQuattro Restaurant Group & Viva Med Spa":client,"DeQuattro Restaurant Group":client,
          "Viva Med Spa & Wellness":client,"Viva Med Spa":client,"Viva Spa":client,"Viva":client}
    for slide in prs.slides:
        for shape in slide.shapes:
            frames=[]
            if getattr(shape,"has_text_frame",False): frames.append(shape.text_frame)
            if getattr(shape,"has_table",False):
                for row in shape.table.rows:
                    for cell in row.cells: frames.append(cell.text_frame)
            for tf in frames:
                for p in tf.paragraphs:
                    for run in p.runs:
                        t=run.text
                        for a,b in reps.items(): t=re.sub(re.escape(a),b,t,flags=re.I)
                        run.text=t
    executive=project["strategy"]["executive"]
    for slide in prs.slides:
        if any(getattr(s,"text","").strip().upper()=="EXECUTIVE SUMMARY" for s in slide.shapes if hasattr(s,"text")):
            boxes=[s for s in slide.shapes if getattr(s,"has_text_frame",False) and len(getattr(s,"text",""))>120]
            if boxes:
                boxes[0].text_frame.clear()
                boxes[0].text_frame.paragraphs[0].text=executive
            break
    prs.save(output)
