#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then echo "Python 3 is required. Install Python 3 from python.org and try again."; read -p "Press Enter to close..."; exit 1; fi
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt
(sleep 2; open http://127.0.0.1:5000) &
python app.py
